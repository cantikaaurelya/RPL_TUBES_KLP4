<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lakukan koneksi ke database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sidp";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $fp_id = $_POST['fp_id'];
    $ro_id = $_POST['ro_id'];
    $pesanan = $_POST['pesanan'];
    $total = $_POST['total'];
    $sign = $_POST['sign'];

    // Lakukan operasi SQL untuk memasukkan data ke dalam tabel Form Final Payment
    $sql_ffp = "INSERT INTO final_payment (fp_id, ro_id, pesanan, total, sign) 
                VALUES ('$fp_id', '$ro_id', '$pesanan', '$total', '$sign')";

    if ($conn->query($sql_ffp) === TRUE) {
        echo "Data Form Final Payment berhasil ditambahkan!";
        // Redirect atau lakukan tindakan lainnya setelah penyimpanan data
        header("Location: FP.html");
        exit();
    } else {
        echo "Error: " . $sql_ffp . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
