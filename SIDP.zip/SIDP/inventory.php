<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=ABeeZee&family=Open+Sans:wght@300&family=Poppins:wght@400;500;600;700&family=Roboto:wght@300;700&family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=ABeeZee&family=Open+Sans:wght@300&family=Poppins:wght@400;500;600;700&family=Roboto:wght@300;700&family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet"></head>
<body class="nav">
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="logo">
                    <img src="images/sal1.png" alt="Logo">
                </div>
                <ul class="nav-links">
                    <li><a href="home.html">Home</a></li>
                    <li><a href="cart.php">Cart</a></li>
                    <li><a href="inventory.php">Inventory</a></li>
                    <li><a href="SO.html">SO</a></li>
                    <li><a href="RO.php">RO</a></li>
                    <li><a href="QC.html">QC</a></li>
                    <li><a href="FP.html">FP</a></li>
                    <li><a href="SJ.html">SJ</a></li>
                    <li><a href="complaint.html">Complaint</a></li>
                    <li><a href="Login.html"><i class="fa fa-sign-out"></i></a></li>
                </ul>
            </div>
        </nav>
    </header>
    <label class="title-inventory">Inventory</label><br>
    <div class="table-container" style="margin-bottom: 500px;">
        <table class="blue-table">
            <thead>
                <tr style="height: 61px;">
                    <th>Kolom</th>
                    <th>Kode Produk</th>
                    <th>Nama Produk</th>
                    <th>Stok</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    // Establish your database connection here
                    $servername = "localhost"; // Your server name
                    $username = "root"; // Your username
                    $password = ""; // Your password
                    $dbname = "sidp"; // Your database name

                    // Create connection
                    $conn = new mysqli($servername, $username, $password, $dbname);

                    // Check connection
                    if ($conn->connect_error) {
                        die("Koneksi gagal: " . $conn->connect_error);
                    }

                    // Query to retrieve data
                    $sql = "SELECT produk.kode_product, produk.nama_product, stock.jumlah FROM produk INNER JOIN stock ON produk.id_produk = stock.id_produk";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $counter = 1; // Counter variable
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                    <td>" . $counter . "</td>
                                    <td>" . $row["kode_product"] . "</td>
                                    <td>" . $row["nama_product"] . "</td>
                                    <td>" . $row["jumlah"] . "</td>
                                </tr>";
                            $counter++; // Increment the counter
                        }
                    } else {
                        echo "<tr><td colspan='4'>No data available</td></tr>";
                    }

                    $conn->close();
                    ?>
            </tbody>
        </table>
    </div>
</body>
<footer>
    <p>SIDP<br>Kelompok 4 RPL IP</p>
</footer>
</html>
