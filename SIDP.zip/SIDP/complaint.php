<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Membuat koneksi ke database
    $servername = "localhost";
    $username = "root";
    $password = ""; 
    $dbname = "sidp"; 

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Pengecekkan koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Mendapatkan inputan dari form
    $perusahaan = $conn->real_escape_string($_POST['perusahaan']);
    $email = $conn->real_escape_string($_POST['email']);
    $complaint = $conn->real_escape_string($_POST['complaint']);

    // Masukkan kedalam database
    $sql = "INSERT INTO complaint (perusahaan, email, complaint) 
            VALUES ('$perusahaan', '$email', '$complaint')";

    if ($conn->query($sql) === TRUE) {
        echo "Data complaint berhasil dikirim";
        header("Location: home.html");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Menutup koneksi database
    $conn->close();
}
?>
