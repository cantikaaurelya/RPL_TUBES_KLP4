<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lakukan koneksi ke database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sidp";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $qc_id = $_POST['qc_id'];
    $so_id = $_POST['so_id'];
    $produk = $_POST['produk'];
    $catatan_qc = $_POST['catatan_qc'];
    $signatureData = $_POST['signature-data'];
    $valid = isset($_POST['valid']) ? 1 : 0;

    // Lakukan operasi SQL untuk memasukkan data ke dalam tabel Form Quality Check
    $sql_fr = "INSERT INTO quality_control (qc_id, so_id, produk, catatan_qc, sign, valid) 
                VALUES ('$qc_id', '$so_id', '$produk', '$catatan_qc', '$signatureData', '$valid')";

    if ($conn->query($sql_fr) === TRUE) {
        header("Location: QC.html");
        echo "Data Form Quality Check berhasil ditambahkan!";
        exit();
    } else {
        echo "Error: " . $sql_fr . "<br>" . $conn->error;
    }

    $conn->close();
}
?>