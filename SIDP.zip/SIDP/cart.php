<?php
session_start();

// Pastikan pengguna sudah masuk sebelum menjalankan sesuatu di cart.php
if (!isset($_SESSION['users_id'])) {
    header("Location: Login.html");
    exit();
}

$users_id = $_SESSION['users_id'];

// Lakukan koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sidp";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query untuk mengambil informasi barang dari tabel keranjang untuk user yang login
$sql = "SELECT * FROM keranjang WHERE users_id = '$users_id'";
$result = $conn->query($sql);
// Fungsi untuk menghapus item dari shopping cart berdasarkan ID produk
function hapusItemDariCart($conn, $users_id, $product_id) {
    $sql = "DELETE FROM keranjang WHERE users_id = '$users_id' AND product_id = '$product_id'";
    $result = $conn->query($sql);
    
    if ($result) {
        return true; // Item berhasil dihapus
    } else {
        return false; // Gagal menghapus item
    }
}

// Cek jika ada parameter POST 'hapus_item' yang dikirim
if (isset($_POST['hapus_item']) && isset($_POST['product_id'])) {
    $product_id_to_delete = $_POST['product_id'];

    if (hapusItemDariCart($conn, $users_id, $product_id_to_delete)) {
        // Redirect kembali ke halaman cart.php setelah menghapus item
        header("Location: cart.php");
        exit();
    } else {
        echo "Gagal menghapus item dari keranjang.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        
        .cart {
            width: 80%;
            margin: 20px auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .title-cart {
            font-size: 24px;
            margin-bottom: 10px;
            color: #333;
        }

        .cart-items {
            border-top: 1px solid #ccc;
            padding-top: 10px;
            margin-top: 10px;
        }

        .cart-item {
            margin-bottom: 5px;
        }

        /* Style checkbox */
        input[type="checkbox"] {
            transform: scale(1.5); /* Memperbesar ukuran checkbox */
            margin-right: 10px;
        }

        /* Style tombol Pesan */
        input[type="submit"] {
            padding: 10px 20px;
            background-color: #3498db;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #2980b9;
        }

        /* Style footer */
        footer {
            text-align: center;
            margin-top: 20px;
            background-color: #333;
            color: #fff;
            padding: 10px 0;
        }
    </style>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=ABeeZee&family=Open+Sans:wght@300&family=Poppins:wght@400;500;600;700&family=Roboto:wght@300;700&family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=ABeeZee&family=Open+Sans:wght@300&family=Poppins:wght@400;500;600;700&family=Roboto:wght@300;700&family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body class="nav">
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="logo">
                    <img src="images/sal1.png" alt="Logo">
                </div>
                <ul class="nav-links">
                    <li><a href="home.html">Home</a></li>
                    <li><a href="cart.php">Cart</a></li>
                    <li><a href="inventory.php">Inventory</a></li>
                    <li><a href="SO.html">SO</a></li>
                    <li><a href="RO.php">RO</a></li>
                    <li><a href="QC.html">QC</a></li>
                    <li><a href="FP.html">FP</a></li>
                    <li><a href="SJ.html">SJ</a></li>
                    <li><a href="complaint.html">Complaint</a></li>
                    <li><a href="Login.html"><i class="fa fa-sign-out"></i></a></li>
                </ul>
            </div>
        </nav>
    </header>
    <section class="cart">
        <div class="cart">
            <label class="title-cart">Shopping Cart</label><br>
            <div class="cart-items">
            <?php
            // Tambahkan tombol hapus pada setiap item di shopping cart
            if ($result->num_rows > 0) {
                echo "<form method='post' action=''>";
                while ($row = $result->fetch_assoc()) {
                    echo "<div class='cart-item'>";
                    echo "<form method='post' action=''>";
                    echo "<input type='checkbox' name='selected_products[]' value='" . $row["product_id"] . "'>" . $row["nama_product"] . "<br>";
                    echo "<input type='hidden' name='product_id' value='" . $row["product_id"] . "'>";
                    echo "<input type='submit' name='hapus_item' value='Hapus'>";
                    echo "</form>";
                    echo "</div>";
                }
                echo "<form method='post' action='SO.html'>"; // Ubah action ke halaman SO.html
                echo "<input type='submit' name='pesan' value='Pesan'>";
                echo "</form>";
            } else {
                echo "No items in the cart.";
            }
            ?>
            </div>
        </div>
    </section>
    <footer>
        <p>SIDP<br>Kelompok 4 RPL IP</p>
    </footer>
</body>
</html>
