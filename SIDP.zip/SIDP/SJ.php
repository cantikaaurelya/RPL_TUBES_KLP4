<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Lakukan koneksi ke database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sidp";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sj_id = $_POST['sj_id'];
    $so_id = $_POST['so_id'];
    $pesanan = $_POST['pesanan'];
    $sign = $_POST['sign'];
    $date = $_POST['date'];
    $valid = isset($_POST['valid']) ? 1 : 0;

    // Lakukan operasi SQL untuk memasukkan data ke dalam tabel Surat Jalan
    $sql_sj = "INSERT INTO surat_jalan (sj_id, so_id, pesanan, sign, date, valid) 
               VALUES ('$sj_id', '$so_id', '$pesanan', '$sign', '$date', '$valid')";

    if ($conn->query($sql_sj) === TRUE) {
        echo "Data Surat Jalan berhasil ditambahkan!";
        // Redirect atau tindakan lainnya setelah penyimpanan data
        header("Location: SJ.html");
        exit();
    } else {
        echo "Error: " . $sql_sj . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
