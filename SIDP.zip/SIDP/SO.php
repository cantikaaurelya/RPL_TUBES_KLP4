<?php
session_start();
if (!isset($_SESSION['users_id'])) {
    // Redirect atau berikan pesan kesalahan jika users_id tidak terdefinisi
    // Misalnya:
    header("Location: error_page.php");
    exit();
}

$users_id = $_SESSION['users_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Koneksi ke database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "sidp";

    // Buat koneksi
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Ambil nilai dari formulir
    $so_id = $_POST['so_id'];
    $customer_name = $_POST['customer_name'];
    $pesanan = $_POST['pesanan'];
    $harga_pcs = $_POST['harga_pcs'];
    $jumlah = $_POST['jumlah'];
    $amount = $_POST['amount'];
    $valid = isset($_POST['valid']) ? 1 : 0;

    // Ambil data tanda tangan dari formulir
    $signatureData = $_POST['signature-pad']; // Ambil dari input hidden yang menyimpan tanda tangan

    // Query SQL untuk menyimpan data ke dalam tabel
    $sql = "INSERT INTO sales_order (so_id, amount, id_customer, valid, customer_name, pesanan, jumlah, harga_pcs, signatureData)
            VALUES ('$so_id', '$amount', '$users_id', '$valid', '$customer_name', '$pesanan', '$jumlah', '$harga_pcs', '$signatureData')";

    if ($conn->query($sql) === TRUE) {
        // Retrieve the last inserted ID
        $last_id = $conn->insert_id;

        // Store the last ID in session for future use
        $_SESSION['so_id'] = $last_id;

        header("Location: RO.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
?>
