<?php
session_start();

$so_id = isset($_SESSION['so_id']) ? $_SESSION['so_id'] : '';
// Tetapkan nilai $so_id ke dalam session
$_SESSION['so_id'] = $so_id;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Pastikan untuk mengatur koneksi ke database MySQL Anda
    $servername = "localhost"; 
    $username = "root"; 
    $password = ""; 
    $dbname = "sidp"; 

    // Buat koneksi ke database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi ke database gagal: " . $conn->connect_error);
    }

    // Query untuk mengambil informasi barang dari tabel keranjang untuk user yang login
    $sql1= "SELECT so_id FROM sales_order";
    $result = $conn->query($sql1);

    // Proses data yang dikirim dari formulir RO
    $ro_id = $_POST['ro_id'];
    $so_id = $_POST['so_id'];
    $spesifikasi = $_POST['spesifikasi'];
    $sign = $_POST['signature-data'];

    // Menyimpan data ke dalam database
    $sql = "INSERT INTO request_order (ro_id, so_id, spesifikasi, sign, tanggal) VALUES ('$ro_id', '$so_id', '$spesifikasi', '$sign', NULL)";

    if ($conn->query($sql) === TRUE) {
        header("Location: Home.html"); // Kembali ke halaman Home jika penyimpanan berhasil
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    // Tutup koneksi ke database
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Order</title>
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=ABeeZee&family=Open+Sans:wght@300&family=Poppins:wght@400;500;600;700&family=Roboto:wght@300;700&family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=ABeeZee&family=Open+Sans:wght@300&family=Poppins:wght@400;500;600;700&family=Roboto:wght@300;700&family=Ubuntu:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body class="nav">
    <header>
        <nav class="navbar">
            <div class="nav-container">
                <div class="logo">
                    <img src="images/sal1.png" alt="Logo">
                </div>
                <ul class="nav-links">
                <li><a href="home.html">Home</a></li>
                    <li><a href="cart.php">Cart</a></li>
                    <li><a href="inventory.php">Inventory</a></li>
                    <li><a href="SO.html">SO</a></li>
                    <li><a href="RO.php">RO</a></li>
                    <li><a href="QC.html">QC</a></li>
                    <li><a href="FP.html">FP</a></li>
                    <li><a href="SJ.html">SJ</a></li>
                    <li><a href="complaint.html">Complaint</a></li>
                    <li><a href="Login.html"><i class="fa fa-sign-out"></i></a></li>
                </ul>
            </div>
        </nav>
    </header>
    <div class="ro">
        <label class="title-ro">Form Request Order</label><br>
        <form action="RO.php" method="post" class="form-ro">
            <div class="mb-3">
                <p style="color: black; font-size: 16px; font-family: 'Open sans', sans-serif;">No.RO
                    <input type="text" name="ro_id" style="margin-left: 102px; width: 1025px;" readonly value="Auto Increment">
                </p>
            </div>
            <div class="mb-3">
            <p style="color: black; font-size: 16px; font-family: 'Open sans', sans-serif;">No.SO
                <input type="text" name="so_id" style="margin-left: 102px; width: 1025px;" readonly value="Auto Increment">
            </p>
            </div>            
            <div class="mb-3">
                <p style="color: black; font-size: 16px; font-family: 'Open sans', sans-serif;">Spesifikasi<textarea name="spesifikasi" id="" cols="134" rows="10" style="margin-left: 74px;"></textarea></p>
            </div>

            <!-- Canvas untuk tanda tangan -->
            <style>
                #signature-pad {
                    border: 1px solid #000; /* Garis border untuk area tanda tangan */
                    margin-bottom: 20px; /* Margin bawah agar terlihat lebih terpisah */
                    width: 200px; /* Atur lebar signature pad */
                    margin-left: 300px;
                }
            
                .button-container {
                    display: flex;
                    justify-content: space-between;
                    width: 210px; /* Sesuaikan lebar dengan lebar signature pad */
                    margin-top: 20px;
                }
            
                .clear-button{
                    width: 40%; /* Sesuaikan lebar tombol */
                    padding: 5px 10px;
                    background-color: #f44336;
                    color: white;
                    border: none;
                    cursor: pointer;
                    text-align: center;
                    margin-left: 300px;
                }
            
                .clear-button:hover, .save-button:hover {
                    background-color: #d32f2f;
                }
            </style>
            
            <!-- Area tanda tangan -->
            <canvas id="signature-pad" width="200" height="150"></canvas>

            <div class="button-container">
                <button class="clear-button">Clear</button>
            </div>

            <input type="hidden" name="signature-pad" id="signature-data">

            <script src="https://cdn.jsdelivr.net/npm/signature_pad"></script>
            <script>
                var canvas = document.getElementById('signature-pad');
                var signaturePad = new SignaturePad(canvas);

                var clearButton = document.querySelector('.clear-button');
                clearButton.addEventListener('click', function (event) {
                    event.preventDefault(); // Menghentikan perilaku default dari tombol
                    signaturePad.clear(); // Menghapus tanda tangan pada signature pad
                });

                // Mengambil tanda tangan dalam format base64 ketika formulir disubmit
                var form = document.querySelector('.form-ro');
                form.addEventListener('submit', function () {
                    // Mendapatkan data tanda tangan dalam format base64
                    var signatureData = signaturePad.toDataURL();
                    // Menetapkan nilai ke input tersembunyi
                    document.getElementById('signature-data').value = signatureData;
                });
            </script>

            <div class="form-btn" style="margin-bottom: 150px;">
                <button type="submit" style="border-radius: 0px;">SUBMIT</button>
            </div>
        </form>
    </div>
</body>
<footer>
    <p>SIDP<br>Kelompok 4 RPL IP</p>
</footer>
</html>
