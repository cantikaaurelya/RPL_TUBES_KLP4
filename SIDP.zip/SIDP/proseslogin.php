<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sidp";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Gunakan prepared statement untuk menghindari SQL Injection
    $stmt = $conn->prepare("SELECT users_id, username FROM users WHERE username=? AND password=?");
    $stmt->bind_param("ss", $username, $password);

    // Lakukan eksekusi query
    $stmt->execute();

    // Ambil hasil dari query
    $result = $stmt->get_result();

    // Periksa apakah ada baris yang cocok
    if ($result->num_rows == 1) {
        // Jika login berhasil, ambil data pengguna
        $row = $result->fetch_assoc();

        // Simpan ID pengguna dan username ke dalam sesi
        $_SESSION['loggedin'] = true;
        $_SESSION['users_id'] = $row['users_id'];
        $_SESSION['username'] = $row['username'];

        // Redirect ke halaman utama
        header("Location: home.html");
        exit();
    } else {
        // Jika login gagal, kembali ke halaman login
        header("Location: Login.html");
        exit();
    }
}

$conn->close();
?>
