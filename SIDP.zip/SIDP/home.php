<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sidp";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_to_cart']) && isset($_POST['kode_product'])&& isset($_POST['nama_product'])&& isset($_POST['harga_pcs'])) {
        // Ambil nilai product_id dari formulir
        $kode_product = $_POST['kode_product'];
        $nama_product = $_POST['nama_product'];
        $harga_pcs = $_POST['harga_pcs'];

        // Ambil user_id dari sesi
        if (isset($_SESSION['users_id'])) {
            $users_id = $_SESSION['users_id'];

            // Query untuk menyimpan produk ke dalam tabel 'keranjang'
            $sql = "INSERT INTO keranjang (users_id, product_id, nama_product, harga_pcs) VALUES ('$users_id', '$kode_product', '$nama_product', '$harga_pcs')";

            if ($conn->query($sql) === TRUE) {
                echo "Product added to cart successfully!";
                // Redirect kembali ke halaman sebelumnya atau halaman lain yang diinginkan setelah menambahkan produk ke keranjang
                header("Location: ".$_SERVER['HTTP_REFERER']);
                exit();
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            // Jika user_id tidak tersedia di sesi, Anda bisa menangani ini dengan memberikan pesan kesalahan atau melakukan sesuatu yang sesuai dengan logika aplikasi Anda
            echo "User session not found!";
        }
    }
}

$conn->close();
?>
