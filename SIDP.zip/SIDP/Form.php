<?php
session_start();
// Lakukan koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sidp";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['submit_fr'])) {
        $no_qc = $_POST['qc_id'];
        $no_so_fr = $_POST['so_id'];
        $produk = $_POST['produk'];
        $catatan_qc = $_POST['catatan_qc'];
        $sign_fr = $_POST['sign'];
        $valid = isset($_POST['valid']) ? 1 : 0;

        // Lakukan operasi SQL untuk memasukkan data ke dalam tabel Form Quality Check
        $sql_fr = "INSERT INTO quality_control (qc_id, so_id, produk, catatan_qc, sign, valid) 
                    VALUES ('$no_qc', '$no_so_fr', '$produk', '$catatan_qc', '$sign_fr', '$valid')";

        if ($conn->query($sql_fr) === TRUE) {
            // Jika berhasil, tambahkan kode notifikasi atau tindakan lainnya di sini
            echo "Data Form Quality Check berhasil ditambahkan!";
        } else {
            echo "Error: " . $sql_fr . "<br>" . $conn->error;
        }
    }

    if (isset($_POST['submit_ffp'])) {
        $no_fp = $_POST['fp_id'];
        $no_ro_ffp = $_POST['ro_id'];
        $pesanan_ffp = $_POST['pesanan_ffp'];
        $total = $_POST['total'];
        $sign_ffp = $_POST['sign_ffp'];

        // Lakukan operasi SQL untuk memasukkan data ke dalam tabel Form Final Payment
        $sql_ffp = "INSERT INTO final_payment (no_fp, no_ro_ffp, pesanan_ffp, total, sign_ffp) 
                    VALUES ('$no_fp', '$no_ro_ffp', '$pesanan_ffp', '$total', '$sign_ffp')";

        if ($conn->query($sql_ffp) === TRUE) {
            // Jika berhasil, tambahkan kode notifikasi atau tindakan lainnya di sini
            echo "Data Form Final Payment berhasil ditambahkan!";
        } else {
            echo "Error: " . $sql_ffp . "<br>" . $conn->error;
        }
    }

    if (isset($_POST['submit_fs'])) {
        $no_sj = $_POST['no_sj'];
        $no_so_fs = $_POST['no_so_fs'];
        $pesanan_fs = $_POST['pesanan_fs'];
        $sign_fs = $_POST['sign_fs'];
        $tanggal = $_POST['tanggal'];

        // Lakukan operasi SQL untuk memasukkan data ke dalam tabel Form Surat Jalan
        $sql_fs = "INSERT INTO form_surat_jalan (no_sj, no_so_fs, pesanan_fs, sign_fs, tanggal) 
                    VALUES ('$no_sj', '$no_so_fs', '$pesanan_fs', '$sign_fs', '$tanggal')";

        if ($conn->query($sql_fs) === TRUE) {
            // Jika berhasil, tambahkan kode notifikasi atau tindakan lainnya di sini
            echo "Data Form Surat Jalan berhasil ditambahkan!";
        } else {
            echo "Error: " . $sql_fs . "<br>" . $conn->error;
        }
    }
}
?>
